# Islands Fisher (Android)
Open this folder in Android Studio (Koala or newer), let Gradle sync, run on a phone (Android 10+).
1. Allow overlay  2. Enable "Islands Fisher" under Accessibility  3. Start (grant screen capture).
Switch to Roblox, drag the red box over the water, press Start on the floating panel.
Reels in when the bobber moves: % of pixels in the box changing between frames, above idle noise. Raise it if it reels too early (ripples), lower it if it misses bites. Keep the box small and tight around the bobber.
