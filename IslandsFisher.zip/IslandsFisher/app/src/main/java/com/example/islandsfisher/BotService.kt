package com.example.islandsfisher

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*

class BotService : Service() {
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private lateinit var box: View
    private lateinit var boxLp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var toggleBtn: Button
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var active = false
    @Volatile private var alive = true
    private var started = false
    private var w = 0; private var h = 0
    private var thr = 4f; private var boxPx = 140
    private var castWait = 2000L; private var reelWait = 3000L; private var timeoutMs = 15000L
    private var fish = 0

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (intent == null || started) return START_NOT_STICKY
        started = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val ch = "fisher"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Fisher", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Islands Fisher running")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        thr = intent.getIntExtra("thr", 4).toFloat()
        boxPx = intent.getIntExtra("box", 140).coerceAtLeast(40)
        castWait = intent.getIntExtra("cast", 2000).toLong()
        reelWait = intent.getIntExtra("reel", 3000).toLong()
        timeoutMs = intent.getIntExtra("timeout", 15) * 1000L

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), intent.getParcelableExtra<Intent>("data")!!)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, ui)
        val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vdisplay = projection!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)

        buildOverlays()
        Thread { loop() }.start()
        return START_NOT_STICKY
    }

    private fun lp(wd: Int, ht: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        wd, ht, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun buildOverlays() {
        box = object : View(this) {
            val p = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 6f }
            override fun onDraw(c: Canvas) { c.drawRect(3f, 3f, width - 3f, height - 3f, p) }
        }
        boxLp = lp(boxPx, boxPx, w / 2 - boxPx / 2, h / 2 - boxPx / 2)
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = boxLp.x; sy = boxLp.y }
                MotionEvent.ACTION_MOVE -> {
                    boxLp.x = (sx + e.rawX - dx).toInt().coerceIn(0, w - boxPx)
                    boxLp.y = (sy + e.rawY - dy).toInt().coerceIn(0, h - boxPx)
                    wm.updateViewLayout(box, boxLp)
                }
            }
            true
        }
        wm.addView(box, boxLp)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC000000.toInt()); setPadding(16, 8, 16, 8)
        }
        statusTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; text = "Place box, press Start" }
        toggleBtn = Button(this).apply { text = "Start"; setOnClickListener { setActive(!active) } }
        val close = Button(this).apply { text = "Close"; setOnClickListener { stopSelf() } }
        panel.addView(statusTv); panel.addView(toggleBtn); panel.addView(close)
        wm.addView(panel, lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 16, 16))
    }

    private fun setActive(a: Boolean) {
        active = a
        boxLp.flags = if (a) boxLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else boxLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(box, boxLp)
        toggleBtn.text = if (a) "Stop" else "Start"
        status(if (a) "Starting..." else "Stopped")
    }

    private fun status(s: String) = ui.post { statusTv.text = "$s | fish: $fish" }

    private fun tap() { TapService.instance?.tap(boxLp.x + boxPx / 2f, boxLp.y + boxPx / 2f) }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    private fun loop() {
        while (alive) {
            if (!active) { sleep(200); continue }
            status("Casting"); tap(); sleep(castWait)
            if (!active) continue
            prev = null
            var avg = 0f
            repeat(6) { avg = maxOf(avg, motion()); sleep(60) }
            val t0 = SystemClock.uptimeMillis(); var best = 0f; var reeled = false; var hits = 0
            // Wait for the fish: only a real jump in bobber movement (above the rolling ripple level) counts.
            while (alive && active) {
                if (timeoutMs > 0 && SystemClock.uptimeMillis() - t0 > timeoutMs) break
                val m = motion(); val d = m - avg
                if (d > best) best = d
                status("Waiting for bite: %.1f%% (best %.1f%%, need %.0f%%)".format(d, best, thr))
                if (d >= thr) { hits++; if (hits >= 2) { tap(); fish++; reeled = true; break } }
                else { hits = 0; avg = avg * 0.95f + m * 0.05f }
                sleep(50)
            }
            if (reeled) status("Reeled in! Recasting soon")
            else if (active) { status("Timed out, resetting"); tap() }
            sleep(reelWait)
        }
    }

    private var prev: IntArray? = null

    /** Percent of sampled pixels in the box whose brightness changed since the last frame (bobber movement). */
    private fun motion(): Float {
        val img = reader?.acquireLatestImage() ?: return 0f
        try {
            val p = img.planes[0]; val buf = p.buffer; val rs = p.rowStride
            val m = 8
            val x0 = (boxLp.x + m).coerceIn(0, w - 1); val x1 = (boxLp.x + boxPx - m).coerceIn(x0, w)
            val y0 = (boxLp.y + m).coerceIn(0, h - 1); val y1 = (boxLp.y + boxPx - m).coerceIn(y0, h)
            val cols = (x1 - x0 + 1) / 2; val rows = (y1 - y0 + 1) / 2
            val cur = IntArray(cols * rows); var k = 0; var y = y0
            while (y < y1 && k < cur.size) {
                var x = x0
                while (x < x1 && k < cur.size) {
                    val i = y * rs + x * 4
                    cur[k++] = ((buf.get(i).toInt() and 255) + (buf.get(i + 1).toInt() and 255) + (buf.get(i + 2).toInt() and 255)) / 3
                    x += 2
                }
                y += 2
            }
            val pv = prev; prev = cur
            if (pv == null || pv.size != cur.size) return 0f
            var c = 0
            for (j in cur.indices) if (Math.abs(cur[j] - pv[j]) > 30) c++
            return c * 100f / cur.size
        } finally { img.close() }
    }

    override fun onDestroy() {
        alive = false; active = false
        try { wm.removeView(box); wm.removeView(panel) } catch (_: Exception) {}
        vdisplay?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
